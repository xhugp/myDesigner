<template>
    <div class="message-release">

    </div>
</template>

<script>
    export default {
        name: "message-release",

    }
</script>

<style scoped>
  *{
    font-family: 微软雅黑;
  }
</style>
