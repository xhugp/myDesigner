<template>
  <div>
    this is lease history page
  </div>
</template>

<script>
    export default {
        name: "lease-history"
    }
</script>

<style scoped>
  *{
    font-family: 微软雅黑;
  }
</style>
