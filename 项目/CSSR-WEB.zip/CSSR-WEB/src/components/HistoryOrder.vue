<template>
    <div class="history-order">
      this is history-order page
    </div>
</template>

<script>
    export default {
        name: "history-order"
    }
</script>

<style scoped>
  *{
    font-family: 微软雅黑;
  }
</style>
