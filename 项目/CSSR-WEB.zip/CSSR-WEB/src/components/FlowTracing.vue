<template>
    <div class="flow-tracing">
      this is flow tracing page
    </div>
</template>

<script>
    export default {
        name: "flow-tracing"
    }
</script>

<style scoped>
  *{
    font-family: 微软雅黑;
  }
</style>
