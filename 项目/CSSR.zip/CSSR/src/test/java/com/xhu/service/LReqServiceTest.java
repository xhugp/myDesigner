package com.xhu.service;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

/**
 * Created by gp on 2018/3/30.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class LReqServiceTest {
    @Test
    @Ignore
    public void list() throws Exception {
    }

    @Test
    @Ignore
    public void delete() throws Exception {
    }

    @Test
    @Ignore
    public void getLReq() throws Exception {
    }

    @Test
    @Ignore
    public void updateResult() throws Exception {
    }

    @Test
    @Ignore
    public void add() throws Exception {

    }

    @Test
    @Ignore
    public void getCount() throws Exception {
    }

}