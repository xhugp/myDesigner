package com.xhu.dao;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

/**
 * Created by gp on 2018/3/22.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class DtypeDaoTest {
    @Test
    public void getName() throws Exception {

    }

    @Test
    public void add() throws Exception {
    }

    @Test
    public void delete() throws Exception {
    }

    @Test
    public void list() throws Exception {
    }

}